import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit{
    registerForm! : any

    constructor(private fb : FormBuilder){ }
    ngOnInit(){ 
      this.registerForm = this.fb.group({ 
      firstName: ['', [Validators.required, Validators.pattern('[a-zA-Z]{3,10}')]], 
      lastName: ['', [Validators.required, Validators.pattern('[a-zA-Z]{3,10}')]], 
      // gender : ['', Validators.required], 
      address: this.fb.group({ 
        addressLine: ['', [Validators.required, Validators.maxLength(10)]], 
        city: ['', [Validators.required]], 
        district: ['', [Validators.required]], 
        state: ['', [Validators.required]], 
        zip: ['', [Validators.required, Validators.pattern('^[1-9]+[0-9]{5}$')]]
       }), 
       // term :['', Validators.requiredTrue], 
       // email: ['', [Validators.required]], 
       // password: ['', [Validators.required]] }); 
       }) 
      }
      onSubmit(){
        console.log(this.registerForm.value)
      }
}